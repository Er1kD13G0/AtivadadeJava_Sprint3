package Atividades_Java;

import javax.swing.JOptionPane;

public class att_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String ND, SH, HT;
		   int nd;
		   float sh, ht, dIR, sb;
		   double dINSS, sl;
		   
		   //nd= numero de dependentes

		   //sh= salario hora

		   //ht = horas trabalhadas
		   
		   ND = JOptionPane.showInputDialog(null, "Digite o numero de depedentes", "Número de dependentes",
				   JOptionPane.QUESTION_MESSAGE);
		  nd = Integer.parseInt(ND);
		   
		   HT = JOptionPane.showInputDialog(null, "Digite o numero de horas trabalhadas", "Horas Trabalhadas",
				   JOptionPane.QUESTION_MESSAGE);
		   Float.parseFloat(HT);
		   
		   SH = JOptionPane.showInputDialog(null, "Digite o salario por hora", "Salario Hora", 
				   JOptionPane.QUESTION_MESSAGE);
				   sh = Float.parseFloat(SH);
		   
		   		ht = Float.parseFloat(SH);
		   		
		   		sb = ht*sh+(50*nd);
		   		
		   		{JOptionPane.showMessageDialog(null, "Salário Bruto" + sb, "Salário Bruto",
		   			JOptionPane.INFORMATION_MESSAGE);}
		   		if (sb<=1000)
		   			
		   		dINSS = sb*8.5/100;
 
   			else
    
   			dINSS = sb*9/100;
 
   			{JOptionPane.showMessageDialog (
   null, "Desconto do INSS" +dINSS , "Desconto do INSS",
   JOptionPane.INFORMATION_MESSAGE );}
 
   if (sb<=500)
 
   dIR = 0;
      
      if (sb>500 && sb<=1000)
 
      dIR = sb*5/100;
 
      else
       
      dIR = sb*7/100;
 
   {JOptionPane.showMessageDialog (
   null, "Desconto do IR" +dIR , "Desconto do IR",
   JOptionPane.INFORMATION_MESSAGE );}
 
   sl = sb-dINSS-dIR;
 
   {JOptionPane.showMessageDialog (
   null, "Salário Líquido" +sl , "Salário Líquido",
   JOptionPane.INFORMATION_MESSAGE ); 
   System.exit( 0 );}
 
}

		
	
		   		
		   		
		   
		   
	}

