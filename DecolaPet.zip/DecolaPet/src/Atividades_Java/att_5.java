package Atividades_Java;
import javax.swing.JOptionPane;

public class att_5 {

    public static void main(String[] args) {

        String x, y, escolha;
        int es;
        float a, b, e;

        escolha = JOptionPane.showInputDialog("Digite 0 para a soma, \n1 para a subtração, \n2 para divisão, \n3 para multiplicação");
        es = Integer.parseInt(escolha);

        x = JOptionPane.showInputDialog("Digite o primeiro número");
        a = Float.parseFloat(x);

        y = JOptionPane.showInputDialog("Digite o segundo número");
        b = Float.parseFloat(y);

        switch (es) {
            case 0:
                e = a + b;
                JOptionPane.showMessageDialog(null, "Resultado da soma: " + e, "Feito", JOptionPane.PLAIN_MESSAGE);
                break;

            case 1:
                e = a - b;
                JOptionPane.showMessageDialog(null, "Resultado da subtração: " + e, "Feito", JOptionPane.PLAIN_MESSAGE);
                break;

            case 2:
                e = a / b;
                JOptionPane.showMessageDialog(null, "Resultado da divisão: " + e, "Feito", JOptionPane.PLAIN_MESSAGE);
                break;

            case 3:
                e = a * b;
                JOptionPane.showMessageDialog(null, "Resultado da multiplicação: " + e, "Feito", JOptionPane.PLAIN_MESSAGE);
                break;

            default:
                JOptionPane.showMessageDialog(null, "Opção inválida", "Erro", JOptionPane.ERROR_MESSAGE);
        }
        System.exit(0);
    }
}
