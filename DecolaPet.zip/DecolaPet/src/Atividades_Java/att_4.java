package Atividades_Java;
import javax.swing.JOptionPane;
public class att_4 {
    public static void main(String[] args) {

String senha; 
String confirmaSenha;

Double x,y;

senha = JOptionPane.showInputDialog(null,"Senha" , "", JOptionPane.QUESTION_MESSAGE);

x = Double.parseDouble(JOptionPane.showInputDialog(null, "Digite o primeiro numero",JOptionPane.QUESTION_MESSAGE));

y = Double.parseDouble(JOptionPane.showInputDialog(null, "Digite o segundo numero",JOptionPane.QUESTION_MESSAGE));

confirmaSenha = JOptionPane.showInputDialog(null, "Digite sua senha novamente", "", JOptionPane.QUESTION_MESSAGE);
    
        if (confirmaSenha.equals(senha)){
            System.out.println(x/y);


        }else{
            System.out.println("Senha Incorreta fechando o aplicativo");
        }
        System.exit(0);
            
        
    }
}