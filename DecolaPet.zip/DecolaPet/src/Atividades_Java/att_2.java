package Atividades_Java;

import javax.swing.JOptionPane;

public class att_2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int aumento;
		float valorProduto;
		
		
		valorProduto = Float.parseFloat(JOptionPane.showInputDialog(null, "R$", "Valor do Produto", JOptionPane.QUESTION_MESSAGE));
		aumento = Integer.parseInt(JOptionPane.showInputDialog(null,"Codigo","Taxa de aumento", JOptionPane.QUESTION_MESSAGE ));	
		
		switch(aumento) {
			
			case 1: valorProduto = valorProduto + (valorProduto*10/100);
			break;
			case 2: valorProduto = valorProduto + (valorProduto*25/100);
			break;
			case 3: valorProduto = valorProduto + (valorProduto*30/100);
			break;
			case 4: valorProduto = valorProduto + (valorProduto*50/100);
			break;
			default: JOptionPane.showMessageDialog(null, "Codigo" + aumento,"Codigo de Aumento Desconhecido" ,JOptionPane.PLAIN_MESSAGE);
			break;
		}
		System.exit(0);
	}

}
