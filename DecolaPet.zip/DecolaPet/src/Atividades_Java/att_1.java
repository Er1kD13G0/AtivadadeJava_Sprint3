package Atividades_Java;

import javax.swing.JOptionPane;

public class att_1 {

    public static void main(String[] args) {

        int numerosdefuncionarios;
        float salariofuncionarios;
        float totaldossalarios = 0; // Inicializar a variável totaldossalarios com zero
        float mediadossalarios;
        int contagem = 0;

        numerosdefuncionarios = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite o Número de Funcionários", "Número de Funcionários", JOptionPane.QUESTION_MESSAGE));

        while (contagem < numerosdefuncionarios) {
            contagem++;
            salariofuncionarios = Float.parseFloat(JOptionPane.showInputDialog(null, "Digite o Salário dos funcionários", "Salário dos Funcionários", JOptionPane.QUESTION_MESSAGE));
            totaldossalarios = totaldossalarios + salariofuncionarios;
        }

        mediadossalarios = totaldossalarios / numerosdefuncionarios;
        System.out.println("Média = " + mediadossalarios);

        System.exit(0);
    }
}
