package Atividades_Java;
import java.awt.Color;
import java.awt.Container;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import java.util.ArrayList;
import javafx.scene.paint.Color;


       


public class att_6 extends JFrame {
	
	private String n;
	private int c;
	private String e;
	private String p;
	private ArrayList<String> nome = new ArrayList<String>();
	private ArrayList<Integer> cpf = new ArrayList<Integer>();
	private ArrayList<String> email = new ArrayList<String>();
	private ArrayList<String> pass = new ArrayList<String>();
	
	public void cadastro(String n, int c, String e, String p) {
		
		this.n = n;
		this.c = c;
		this.e = e;
		this.p = p;
	}
	public void menu(){
		setVisible(false);
		
		
		Container janela = getContentPane();
		setLayout(null);
		janela.removeAll();
		JLabel labelTitle = new JLabel("EcoStar");
		JLabel labelText = new JLabel("Seja bem vindo à página de cadastros!");
		JLabel labelOpt = new JLabel("Selecione a opção desejada: ");
		labelTitle.setBounds(230, 10, 100, 20);
		labelText.setBounds(30, 80, 250, 20);
		labelOpt.setBounds(30,110, 200, 20);
		
		JButton buttonCad = new JButton("Novo Cadastro");
		JButton buttonShow = new JButton("Mostrar Cadastros");
		JButton buttonExit = new JButton("Sair");
		buttonCad.setBounds(10, 170, 160, 20);
		buttonShow.setBounds(180, 170, 160, 20);
		buttonExit.setBounds(350, 170, 160, 20);
		
		janela.add(labelTitle);
		janela.add(labelText);
		janela.add(labelOpt);
		janela.add(buttonCad);
		janela.add(buttonShow);
		janela.add(buttonExit);
		setSize(550,300);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Cadastro");
		setVisible(true);
		janela.setBackground(Color.decode("#c1dbda"));
		ImageIcon img = new ImageIcon("C:\\Users\\Aluno\\Downloads\\Cadastro_Produto\\iconNemesis.png");
		setIconImage(img.getImage());
		
		buttonCad.addActionListener(e -> newCad());
		buttonShow.addActionListener(e -> showCad());
		buttonExit.addActionListener(e -> exit());
	}
	
	public void newCad() {
		setVisible(false);
		
		cadastro(
				inputDialog("Insira o nome: ", "Cadastro"),
				Integer.parseInt(inputDialog("Insira seu CPF: ", "Cadastro")),
				inputDialog("Insira o seu email: ", "Cadastro"),
				inputDialog("Insira a sua senha: ", "Cadastro")
				);
		nome.add(n);
		cpf.add(c);
		email.add(e);
		pass.add(p);
		
		
		
		Container novo = getContentPane();
		setLayout(null);
		novo.removeAll();
		JLabel labelTitle = new JLabel("EcoStar");
		JLabel labelText = new JLabel("Seu cadastro foi realizado com sucesso!");
		labelTitle.setBounds(230, 10, 100, 20);
		labelText.setBounds(30, 80, 250, 20);
		
		JButton Continuar = new JButton("Novo");
		JButton Menu = new JButton("Voltar");
		JButton Sair = new JButton("Sair");
		Continuar.setBounds(10, 160, 145, 20);
		Menu.setBounds(170, 160, 145, 20); 
		Sair.setBounds(330, 160, 145, 20);
		novo.setSize(550,300);
		novo.add(labelTitle);
		novo.add(labelText);
		novo.add(Continuar);
		novo.add(Menu);
		novo.add(Sair);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setTitle("Cadastro");
		novo.setBackground(Color.decode("#c1dbda"));
		
		
		
		
		setVisible(true);
		
		Continuar.addActionListener(e -> newCad());
		Menu.addActionListener(e -> menu());
		Sair.addActionListener(e -> exit());
		
	
	}
	public void showCad() {
		setVisible(false);
		JOptionPane.showMessageDialog(null, "Nome: " + nome + "\nEmail:" + email, "Cadastrados", JOptionPane.INFORMATION_MESSAGE);
		
		
	
	}
	public void exit() {
		setVisible(false);
		JOptionPane.showMessageDialog(null, "Obrigado pela preferência!", "Cadastro", JOptionPane.INFORMATION_MESSAGE);
		System.exit(0);
	}
	
	public String inputDialog(String message, String title) {
		String entrada = JOptionPane.showInputDialog(null, message, title, JOptionPane.INFORMATION_MESSAGE);
		if (entrada == null) {
			System.exit(0);
			return "";
		}else {
			if (entrada == "" || entrada.length() <= 0) {
				JOptionPane.showMessageDialog(null, "O texto não pode ficar vazio!", "Cadastro", JOptionPane.ERROR_MESSAGE);
				return inputDialog(message,title);
			}else {
				return entrada;
			}
		}
	}
}



    
    


