package Tela_Java;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class View_Tela {
    private JFrame frame;
    private JTextField textField;
    private JPasswordField passwordField;
    private JTextField textField_1;
    private String email;
    private String senha;
    private String usuario;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    View_Tela window = new View_Tela();
                    window.frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public View_Tela() {
        initialize();
    }

    private void initialize() {
        frame = new JFrame();
        frame.setBounds(100, 100, 518, 487);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(null);

        JPanel panel = new JPanel();
        panel.setBackground(new Color(4, 150, 216));
        panel.setBounds(0, 0, 504, 450);
        frame.getContentPane().add(panel);
        panel.setLayout(null);

        JLabel label = new JLabel("");
        label.setIcon(new ImageIcon(View_Tela.class.getResource("/Imagens/logo sem fundo(2).png")));
        label.setBounds(0, -11, 97, 84);
        panel.add(label);

        JLabel lblNewLabel = new JLabel("Selecione uma opção:");
        lblNewLabel.setForeground(Color.WHITE);
        lblNewLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
        lblNewLabel.setBounds(177, 134, 162, 22);
        panel.add(lblNewLabel);

        JComboBox<String> comboBox_1 = new JComboBox<String>();
        comboBox_1.setFont(new Font("SansSerif", Font.PLAIN, 12));
        comboBox_1.setBounds(10, 167, 170, 22);
        panel.add(comboBox_1);


        comboBox_1.addItem("Entrar");
        comboBox_1.addItem("Registrar");


        comboBox_1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String selectItem = (String) comboBox_1.getSelectedItem();
                if (selectItem.equals("Entrar")) {
                    JOptionPane.showMessageDialog(comboBox_1, "Você entrou com sucesso!");
                } else if (selectItem.equals("Registrar")) {
                    frame.setVisible(false);

                    JFrame registerFrame = new JFrame();
                    registerFrame.setBounds(100, 100, 518, 487);
                    registerFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    registerFrame.getContentPane().setLayout(null);
                    registerFrame.setVisible(true);

                    JPanel registerPanel = new JPanel();
                    registerPanel.setBackground(new Color(4, 150, 216));
                    registerPanel.setBounds(0, 0, 504, 450);
                    registerFrame.getContentPane().add(registerPanel);
                    registerPanel.setLayout(null);

                    JLabel emailLabel = new JLabel("Email");
                    emailLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
                    emailLabel.setForeground(Color.WHITE);
                    emailLabel.setBounds(10, 221, 49, 14);
                    registerPanel.add(emailLabel);
                    

                    JLabel senhaLabel = new JLabel("Senha");
                    senhaLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
                    senhaLabel.setForeground(Color.WHITE);
                    senhaLabel.setBounds(445, 221, 49, 14);
                    registerPanel.add(senhaLabel);

                    textField = new JTextField();
                    textField.setFont(new Font("Lucida Sans Unicode", Font.PLAIN, 12));
                    textField.setBounds(10, 246, 402, 22);
                    registerPanel.add(textField);
                    textField.setColumns(10);

                    passwordField = new JPasswordField();
                    passwordField.setFont(new Font("Lucida Sans Unicode", Font.PLAIN, 12));
                    passwordField.setBounds(445, 246, 49, 22);
                    registerPanel.add(passwordField);

                    JLabel usuarioLabel = new JLabel("Usuário");
                    usuarioLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
                    usuarioLabel.setForeground(Color.WHITE);
                    usuarioLabel.setBounds(10, 288, 71, 14);
                    registerPanel.add(usuarioLabel);

                    textField_1 = new JTextField();
                    textField_1.setFont(new Font("Lucida Sans Unicode", Font.PLAIN, 12));
                    textField_1.setColumns(10);
                    textField_1.setBounds(10, 313, 402, 22);
                    registerPanel.add(textField_1);

                    JButton cadastrarButton = new JButton("Cadastrar");
                    cadastrarButton.setFont(new Font("SansSerif", Font.BOLD, 12));
                    cadastrarButton.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                            email = textField.getText();
                            senha = new String(passwordField.getPassword());
                            usuario = textField_1.getText();
                            JOptionPane.showMessageDialog(registerPanel, "Cadastro realizado com sucesso!");
                        }
                    });
                    cadastrarButton.setBounds(10, 380, 120, 36);
                    registerPanel.add(cadastrarButton);

                    JButton visualizarButton = new JButton("Visualizar Cadastros");
                    visualizarButton.setFont(new Font("SansSerif", Font.BOLD, 12));
                    visualizarButton.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                            String cadastros = "Email: " + email + "\n" +
                                    "Senha: " + senha + "\n" +
                                    "Usuário: " + usuario;
                            JOptionPane.showMessageDialog(registerPanel, cadastros);
                        }
                    });
                    visualizarButton.setBounds(180, 380, 170, 36);
                    registerPanel.add(visualizarButton);

                    JButton sairButton = new JButton("Sair");
                    sairButton.setFont(new Font("SansSerif", Font.BOLD, 12));
                    sairButton.addActionListener(new ActionListener() {
                        public void actionPerformed(ActionEvent e) {
                            JOptionPane.showMessageDialog(registerPanel, "Saindo do Aplicativo");
                            System.exit(0);
                        }
                    });
                    sairButton.setBounds(350, 380, 120, 36);
                    registerPanel.add(sairButton);
                    
                  

                }
            }
        });
    
}
        };
    


